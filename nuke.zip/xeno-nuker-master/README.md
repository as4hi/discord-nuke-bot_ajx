# Xeno Nuker
A discord server nuker by Xeno#0538

# Installation
First, download the repo by clicking `↓ Code`,
After downloading the repo, extract it anywhere
Next, run `install.bat`\
Wait for everything to install\
Then you are done installing the required packages!

# Setup
Before you do anything, make sure you rename `config.example.json` to `config.json`

Next, create a bot, then call it anything, then get it's token and paste it into `config.json`

Next, invite the bot to the target server

You should choose a desired prefix for the bot, or you can leave it as `!`

You should also add in the target server ID so then you can raid the server using these commands:\
`raid` > That raids the server [BOT MUST HAVE ADMINISTRATOR PERMISSIONS & Bots role must be the highest]\
`reset` > That resets the entire server [BOT MUST HAVE ADMINISTRATOR PERMISSIONS & Bots role must be the highest]
Other commands:
`help` > shows all of the avalible commands for the bot

So far, your config file should look like this
```json
{
    "token": "token-here",
    "prefix": "!",
    "targetID": "server-id-here"
}
```

# Run the bot
To run the bot, just run `launch.bat`. Now the bot should be online and raiding the target server via commands :)

# Xeno Nuker ToS

1. You MUST NOT claim the code as your own code
2. You MUST NOT claim owner ship of the bot

# Xeno Nuker Risks

I am not responsible for any actions taken when using this bot. Please use at your own risk.